package co.edu.uniquindio.poo;

/**
 * Hello world!
 *  /persona:
-nombre 
-profession
-actividad 
+seleccionar
/profesor:
- trabajo 
+preparar
/profesor ingeniero:
- materia
+ tema
 * 
 * 
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
